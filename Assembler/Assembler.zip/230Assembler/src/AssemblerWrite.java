import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Scanner;

public class AssemblerWrite {
	public static void AssemblerWriter(ArrayList<String> al, Writer write){
		
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(write);
			for (int i = 0; i < al.size(); i++){
				bw.write(al.get(i));
			}
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
