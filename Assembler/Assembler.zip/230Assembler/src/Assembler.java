import java.io.File;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.lang.Object;
import org.apache.commons.lang3.*;
import org.apache.commons.lang3.StringUtils;

public class Assembler {
	public static ArrayList<String> AssembleInstruction(ArrayList<String> lines){
		//R type Strings to concatenate, then int typecast
		/*
		 * There can only be a total of 16 possible opCodes
		 */
		String immediateInt = "";
		String opCode = "";
		String opX = "";
		String cond = "";
		String set = "0";
		String register = "";
		String machineCode = "";
		ArrayList<String> machineCodes = new ArrayList<String>();
		for (int i = 0; i < lines.size(); i++){
			String [] instElements = lines.get(i).trim().split(" ");
			
			//loop through elements to determine machine code
			for (int j = 0; j < instElements.length; j++){
				char[] charArray = instElements[j].toCharArray();
				if (instElements[j] == "jr") {
					opCode = "0001";
					opX = "000";
					cond = "0000";
				}
				if (instElements[j] == "cmp") {
					opCode = "0010";
					opX = "000";
					cond = "0000";
					set = "1";
				}
				if (instElements[j] == "lw") {
					opCode = "0100";
					cond = "0000";
				}
				if (instElements[j] == "sw") {
					opCode = "0101";
					cond = "0000";
				}
				if (instElements[j].equalsIgnoreCase("si")){
					opCode = "0111";
					cond = "0000";
				}
				if (instElements[j] == "addi") {
					opCode = "0110";
					cond = "0000";
				}
				if (instElements[j] == "subi") {
					opCode = "0111";
					cond = "0000";
				}
				/*
				 * BRANCH conditional options
				 */
				//branch always
				if (instElements[j] == "b") {
					opCode = "1000";
					cond = "0000";
					//include logic here for COND?
					//probably not because 
				}
				//branch if equals
				if (instElements[j] == "beq") {
					opCode = "1000";
					cond = "0010";
				}
				//branch if not equal
				if (instElements[j] == "bne") {
					opCode = "1000";
					cond = "0011";
				}
				//branch if positive or zero
				if (instElements[j] == "bpz") {
					opCode = "1000";
					cond = "0111";
				}
				//branch if greater than
				if (instElements[j] == "bgt") {
					opCode = "1000";
					cond = "1100";
				}
				//branch if less than
				if (instElements[j] == "blt") {
					opCode = "1000";
					cond = "1101";
				}
				//branch if greater than or equal to
				if (instElements[j] == "bge") {
					opCode = "1000";
					cond = "1110";
				}
				//branch if less than or equal
				if (instElements[j] == "ble") {
					opCode = "1000";
					cond = "1111";
				}
				/*
				 * BRANCH AND LINK conditional options
				 */
				//branch and link always
				if (instElements[j] == "bal"){
					opCode = "1001";
					cond = "0000";
				}
				//branch and link if equal
				if (instElements[j] == "baleq") {
					opCode = "1001";
					cond = "0010";
				}
				//branch if positive or zero
				if (instElements[j] == "balpz") {
					opCode = "1001";
					cond = "0111";
				}
				//branch if greater than
				if (instElements[j] == "balgt") {
					opCode = "1001";
					cond = "1100";
				}
				//branch if less than
				if (instElements[j] == "ballt") {
					opCode = "1001";
					cond = "1101";
				}
				//branch if greater than or equal
				if (instElements[j] == "balge") {
					opCode = "1001";
					cond = "1110";
				}
				//branch if less than or equal
				if (instElements[j] == "balle") {
					opCode = "1001";
					cond = "1111";
				}
				
				machineCode = opCode + cond + set + opX;
				/*
				 * ifs to determine the register files
				 */
				if (instElements[j] == "r0") {
					register = "0000";
					machineCode += register;
				}
				if (instElements[j] == "r1") {
					register = "0001";
					machineCode += register;
				}
				if (instElements[j] == "r2") {
					register = "0010";
					machineCode += register;
				}
				if (instElements[j] == "r3") {
					register = "0011";
					machineCode += register;
				}
				if (instElements[j] == "r4") {
					register = "0100";
					machineCode += register;
				}
				if (instElements[j] == "r5") {
					register = "0101";
					machineCode += register;
				}
				if (instElements[j] == "r6") {
					register = "0110";
					machineCode += register;
				}
				if (instElements[j] == "r7") {
					register = "0111";
					machineCode += register;
				}
				if (instElements[j] == "r8") {
					register = "1000";
					machineCode += register;
				}
				if (instElements[j] == "r9") {
					register = "1001";
					machineCode += register;
				}
				if (instElements[j] == "r10") {
					register = "1010";
					machineCode += register;
				}
				if (instElements[j] == "r11") {
					register = "1011";
					machineCode += register;
				}
				if (instElements[j] == "r12") {
					register = "1100";
					machineCode += register;
				}
				if (instElements[j] == "r13") {
					register = "1101";
					machineCode += register;
				}
				if (instElements[j] == "r14") {
					register = "1110";
					machineCode += register;
				}
				if (instElements[j] == "r15") {
					register = "1111";
					machineCode += register;
				}
				
				//need codes for stack pointer...does it just point to register
				//NEED TO ADD MACHINE CODE FOR IMMEDIATE VALUES
				if (isNumeric(charArray) == true){
					String addTo = null;
					for (int k = 0; k < charArray.length; k++){
						addTo += charArray[k];
					}
					Integer a = Integer.parseInt(addTo);
					String b = Integer.toBinaryString(a);
					immediateInt = b;
					while (immediateInt.length() < 7) {
						immediateInt = "0" + immediateInt;
					}
					machineCode += immediateInt;
				}
				machineCodes.add(machineCode);
			}
		}
		
		return machineCodes;
	}
	
	//similar to org.apache.commons.lang3
	public static boolean isNumeric(final char[] cs) {
		if (cs == null) {
			return false;
		}
		final int sz = cs.length;
		for (int i = 0; i < sz; i++) {
			if (!Character.isDigit(cs[i])){
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args){
		File asm = new File("data/AssemblerTest.txt");
		ArrayList<String> lines = AssemblyReader.AssemblyLines(asm);
		lines = AssembleInstruction(lines);
		Writer write;
		
		/*
		 * need to export each ArrayList item to a file
		 * with newline character per instruction
		 * Look in MIF example file for output format 
		 */
	}

}
