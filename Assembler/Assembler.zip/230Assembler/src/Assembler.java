import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.lang.Object;

import org.apache.commons.lang3.*;
import org.apache.commons.lang3.StringUtils;

public class Assembler {
	//opCode,Cond,s,opX,rd,rs,rt r-type
	public static ArrayList<String> AssembleInstruction(ArrayList<String> lines){
		//R type Strings to concatenate, then int typecast
		/*
		 * There can only be a total of 16 possible opCodes
		 */
		//HashMap<String, String> hm = new HashMap<String, String>();
		//hm.put("r0", "0000");
		//hm.put("r1", "0001");
		//hm.put("r2", "0010");
		//hm.put("r3", "0011");
		//hm.put("r4", "0100");
		//hm.put("r5", "0101");
		//hm.put("r6", "0110");
		//hm.put("r7", "0111");
		//hm.put("r8", "1000");
		//hm.put("r9", "1001");
		//hm.put("r10", "1010");
		//hm.put("r11", "1011");
		//hm.put("r12", "1100");
		//hm.put("r13", "1101");
		//hm.put("r14", "1110");
		//hm.put("r15", "1111");
		String[] instructionList = new String[5];
		String immediateInt = "";
		String opCode = "";
		String opX = "";
		String cond = "";
		String set = "0";
		String register = ""; //need to add more register space and differentiate them
		String machineCode = "";
		ArrayList<String> machineCodes = new ArrayList<String>();
		for (int i = 0; i < lines.size(); i++){
			String [] instElements = lines.get(i).trim().split(" ");
			System.out.println("\n");
			//loop through elements to determine machine code
			for (int j = 0; j < instElements.length; j++){
				char[] charArray = instElements[j].toCharArray();
				register = "";
				if (instElements[j] == "jr") {
					int op = 0001;
					opCode = Integer.toHexString(op);
					int o = 000;
					opX = Integer.toHexString(o);
					int c = 0000;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond + set + opX;
				}
				if (instElements[j] == "cmp") {
					int op = 0010;
					opCode = Integer.toHexString(op);
					int o = 000;
					opX = Integer.toHexString(o);
					int c = 0000;
					cond = Integer.toHexString(c);
					int s = 1;
					set = Integer.toHexString(s);
					machineCode += opCode + cond + set + opX;
				}
				if (instElements[j] == "lw") {
					int op = 0100;
					opCode = Integer.toHexString(op);
					int c = 0000;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond + set;
				}
				if (instElements[j] == "sw") {
					int op = 0101;
					opCode = Integer.toHexString(op);
					int c = 0000;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond + set;
				}
				if (instElements[j].equalsIgnoreCase("si")){
					int op = 0111;
					opCode = Integer.toHexString(op);
					int c = 0000;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond + set;
				}
				if (instElements[j] == "addi") {
					int op = 0110;
					opCode = Integer.toHexString(op);
					int c = 0000;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond + set;
				}
				if (instElements[j] == "subi") {
					int op = 0111;
					opCode = Integer.toHexString(op);
					int c = 0000;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond + set;
				}
				/*
				 * BRANCH conditional options
				 */
				//branch always
				if (instElements[j] == "b") {
					int op = 1000;
					opCode = Integer.toHexString(op);
					int c = 0000;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if equals
				if (instElements[j] == "beq") {
					int op = 1000;
					opCode = Integer.toHexString(op);
					int c = 0010;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if not equal
				if (instElements[j] == "bne") {
					int op = 1000;
					opCode = Integer.toHexString(op);
					int c = 0011;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if positive or zero
				if (instElements[j] == "bpz") {
					int op = 1000;
					opCode = Integer.toHexString(op);
					int c = 0111;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if greater than
				if (instElements[j] == "bgt") {
					int op = 1000;
					opCode = Integer.toHexString(op);
					int c = 1100;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if less than
				if (instElements[j] == "blt") {
					int op = 1000;
					opCode = Integer.toHexString(op);
					int c = 1101;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if greater than or equal to
				if (instElements[j] == "bge") {
					int op = 1000;
					opCode = Integer.toHexString(op);
					int c = 1110;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if less than or equal
				if (instElements[j] == "ble") {
					int op = 1000;
					opCode = Integer.toHexString(op);
					int c = 1111;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				/*
				 * BRANCH AND LINK conditional options
				 */
				//branch and link always
				if (instElements[j] == "bal"){
					int op = 1001;
					opCode = Integer.toHexString(op);
					int c = 0000;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch and link if equal
				if (instElements[j] == "baleq") {
					int op = 1001;
					opCode = Integer.toHexString(op);
					int c = 0010;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if positive or zero
				if (instElements[j] == "balpz") {
					int op = 1001;
					opCode = Integer.toHexString(op);
					int c = 0111;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if greater than
				if (instElements[j] == "balgt") {
					int op = 1001;
					opCode = Integer.toHexString(op);
					int c = 1100;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if less than
				if (instElements[j] == "ballt") {
					int op = 1001;
					opCode = Integer.toHexString(op);
					int c = 1101;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if greater than or equal
				if (instElements[j] == "balge") {
					int op = 1001;
					opCode = Integer.toHexString(op);
					int c = 1110;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				//branch if less than or equal
				if (instElements[j] == "balle") {
					int op = 1001;
					opCode = Integer.toHexString(op);
					int c = 1111;
					cond = Integer.toHexString(c);
					machineCode += opCode + cond;
				}
				
				
				/*
				 * ifs to determine the register files
				 */
				if (instElements[j] == "r0") {
					int r = 0000;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r1") {
					int r = 0001;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r2") {
					int r = 0010;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r3") {
					int r = 0011;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r4") {
					int r = 0100;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r5") {
					int r = 0101;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r6") {
					int r = 0110;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r7") {
					int r = 0111;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r8") {
					int r = 1000;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r9") {
					int r = 1001;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r10") {
					int r = 1010;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r11") {
					int r = 1011;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r12") {
					int r = 1100;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r13") {
					int r = 1101;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r14") {
					int r = 1110;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				if (instElements[j] == "r15") {
					int r = 1111;
					register = Integer.toHexString(r);
					machineCode += register;
				}
				
				//need codes for stack pointer...does it just point to register
				//NEED TO ADD MACHINE CODE FOR IMMEDIATE VALUES
				if (isNumeric(charArray) == true){
					String addTo = "";
					for (int k = 0; k < charArray.length; k++){
						addTo += charArray[k];
					}
					Integer a = Integer.parseInt(addTo);
					String b = Integer.toHexString(a);
					immediateInt = b;
					while (immediateInt.length() < 7) {
						immediateInt = "0" + immediateInt;
					}
					int imm = Integer.parseInt(immediateInt);
					immediateInt = Integer.toHexString(imm);
					machineCode += immediateInt;
				}
				
			}
			machineCode += "\n";
			machineCodes.add(machineCode);
		}
		
		return machineCodes;
	}
	
	//similar to org.apache.commons.lang3
	public static boolean isNumeric(final char[] cs) {
		if (cs == null) {
			return false;
		}
		final int sz = cs.length;
		for (int i = 0; i < sz; i++) {
			if (!Character.isDigit(cs[i])){
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args){
		File asm = new File("data/AssemblerTest.txt");
		ArrayList<String> lines = AssemblyReader.AssemblyLines(asm);
		lines = AssembleInstruction(lines);
		PrintWriter writer;
		try {
			writer = new PrintWriter("data/Assembled.txt", "UTF-8");
			AssemblerWrite.AssemblerWriter(lines, writer);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		/*
		 * need to export each ArrayList item to a file
		 * with newline character per instruction
		 * Look in MIF example file for output format 
		 */
	
	}

}
