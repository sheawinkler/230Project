import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class AssemblyReader {
	public static ArrayList<String> AssemblyLines(File asmFile){
		File file = asmFile;
		ArrayList<String> line = new ArrayList<String>();
		Scanner sc;
		try {
			sc = new Scanner(file);
			while (sc.hasNextLine()) {
	            String s = sc.nextLine();
	            line.add(s);
	        }
	        sc.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        return line;
	
	}
}
