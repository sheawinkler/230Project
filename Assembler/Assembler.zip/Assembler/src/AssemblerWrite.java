import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Scanner;

public class AssemblerWrite {
	public static void AssemblerWriter(ArrayList<String> al, Writer write){
		
		BufferedWriter bw;
		
		try {
			bw = new BufferedWriter(write);
			//write String of binary numbers to MIF file
			bw.write(
"-- Shea Winkler and Team 2 generated Memory Initialization File (.mif) \n" +
"\n"+
"WIDTH=24;\n" +
"DEPTH=1024\n" +
"\n"+
"ADDRESS_RADIX=UNS;\n" +
"DATA_RADIX=HEX;\n" +
"\n" +
"CONTENT BEGIN" +
"\n");
			for (int i = 0; i < al.size(); i++){
				
				bw.write(al.get(i));
			}
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
