import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.lang.Object;

public class Assembler {
	public static ArrayList<String> AssembleInstruction(ArrayList<String> lines){
		//R type Strings to concatenate, then int typecast
		/*
		 * There can only be a total of 16 possible opCodes
		 */
		//HashMap<String, String> hm = new HashMap<String, String>();
		//hm.put("r0", "0000");
		//hm.put("r1", "0001");
		//hm.put("r2", "0010");
		//hm.put("r3", "0011");
		//hm.put("r4", "0100");
		//hm.put("r5", "0101");
		//hm.put("r6", "0110");
		//hm.put("r7", "0111");
		//hm.put("r8", "1000");
		//hm.put("r9", "1001");
		//hm.put("r10", "1010");
		//hm.put("r11", "1011");
		//hm.put("r12", "1100");
		//hm.put("r13", "1101");
		//hm.put("r14", "1110");
		//hm.put("r15", "1111");
		String immediateInt = "0000000";
		String opCode = "0000";
		String opX = "000";
		String cond = "0000";
		String set = "0";
		String register = "0000";
		String machineCode = "";
		ArrayList<String> machineCodes = new ArrayList<String>();
		for (int i = 0; i < lines.size(); i++){
			String [] instElements = lines.get(i).split(" ");
			//loop through elements to determine machine code
			for (int j = 0; j < instElements.length; j++){

				if (instElements[j].equalsIgnoreCase("jr")) {
					opCode = "0001";
					opX = "000";
					cond = "0000";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("cmp")) {
					opCode = "0010";
					opX = "000";
					cond = "0000";
					set = "1";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("lw")) {
					opCode = "0100";
					cond = "0000";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("sw")) {
					opCode = "0101";
					cond = "0000";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("si")){
					opCode = "0111";
					cond = "0000";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("addi")) {
					opCode = "0110";
					cond = "0000";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("subi")) {
					opCode = "0111";
					cond = "0000";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("add")){
					opCode = "0000";
					cond = "0000";
					opX = "100";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("sub")){
					opCode = "0000";
					cond = "0000";
					opX = "011";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("and")) {
					opCode = "0000";
					cond = "0000";
					opX = "111";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("or")){
					opCode = "0000";
					cond = "0000";
					opX = "110";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("xor")){
					opCode = "0000";
					cond = "0000";
					opX = "101";
					machineCode += opCode + cond + set + opX;
				}
				else if (instElements[j].equalsIgnoreCase("sll")){
					opCode = "0011";
					cond = "0000";
					opX = "000";
					machineCode += opCode + cond + set + opX;
					
				}
				/*
				 * BRANCH conditional options
				 */
				//branch always
				else if (instElements[j].equalsIgnoreCase("b")) {
					opCode = "1000";
					cond = "0000";

					machineCode += opCode + cond + set + opX;
				}
				//branch else if equalsIgnoreCase
				else if (instElements[j].equalsIgnoreCase("beq")) {
					opCode = "1000";
					cond = "0010";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if not equal
				else if (instElements[j].equalsIgnoreCase("bne")) {
					opCode = "1000";
					cond = "0011";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if positive or zero
				else if (instElements[j].equalsIgnoreCase("bpz")) {
					opCode = "1000";
					cond = "0111";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if greater than
				else if (instElements[j].equalsIgnoreCase("bgt")) {
					opCode = "1000";
					cond = "1100";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if less than
				else if (instElements[j].equalsIgnoreCase("blt")) {
					opCode = "1000";
					cond = "1101";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if greater than or equal to
				else if (instElements[j].equalsIgnoreCase("bge")) {
					opCode = "1000";
					cond = "1110";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if less than or equal
				else if (instElements[j].equalsIgnoreCase("ble")) {
					opCode = "1000";
					cond = "1111";
					machineCode += opCode + cond + set + opX;
				}
				/*
				 * BRANCH AND LINK conditional options
				 */
				//branch and link always
				else if (instElements[j].equalsIgnoreCase("bal")){
					opCode = "1001";
					cond = "0000";
					machineCode += opCode + cond + set + opX;
				}
				//branch and link else if equal
				else if (instElements[j].equalsIgnoreCase("baleq")) {
					opCode = "1001";
					cond = "0010";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if positive or zero
				else if (instElements[j].equalsIgnoreCase("balpz")) {
					opCode = "1001";
					cond = "0111";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if greater than
				else if (instElements[j].equalsIgnoreCase("balgt")) {
					opCode = "1001";
					cond = "1100";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if less than
				else if (instElements[j].equalsIgnoreCase("ballt")) {
					opCode = "1001";
					cond = "1101";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if greater than or equal
				else if (instElements[j].equalsIgnoreCase("balge")) {
					opCode = "1001";
					cond = "1110";
					machineCode += opCode + cond + set + opX;
				}
				//branch else if less than or equal
				else if (instElements[j].equalsIgnoreCase("balle")) {
					opCode = "1001";
					cond = "1111";
					machineCode += opCode + cond + set + opX;
				}


				/*
				 * else ifs to determine the register files
				 */
				else if (instElements[j].equalsIgnoreCase("r0")) {
					register = "0000";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r1")) {
					register = "0001";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r2")) {
					register = "0010";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r3")) {
					register = "0011";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r4")) {
					register = "0100";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r5")) {
					register = "0101";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r6")) {
					register = "0110";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r7")) {
					register = "0111";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r8")) {
					register = "1000";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r9")) {
					register = "1001";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r10")) {
					register = "1010";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r11")) {
					register = "1011";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r12")) {
					register = "1100";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r13")) {
					register = "1101";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r14")) {
					register = "1110";
					machineCode += register;
				}
				else if (instElements[j].equalsIgnoreCase("r15")) {
					register = "1111";
					machineCode += register;
				}

				//need codes for stack pointer
				//NEED TO ADD MACHINE CODE FOR IMMEDIATE VALUES
				char[] charArray = instElements[j].toCharArray();
				if (isNumeric(charArray) == true){
					String addTo = "";
					for (int k = 0; k < charArray.length; k++){
						addTo += charArray[k];
					}
					int a = Integer.parseInt(addTo);
					addTo = Integer.toBinaryString(a);
					/*
					 * We have no idea how negative values work
					 */
					immediateInt = addTo;
					if (immediateInt.length() < 7) {
						int zeroes = 7 - machineCode.length();
						if (zeroes == 6) {
							immediateInt += "000000" + immediateInt;
						}
						else if (zeroes == 5) {
							immediateInt += "00000" + immediateInt;
						}
						else if (zeroes == 4) {
							immediateInt += "0000" + immediateInt;
						}
						else if (zeroes == 3) {
							immediateInt += "000" + immediateInt;
						}
						else if (zeroes == 2) {
							immediateInt += "00" + immediateInt;
						}
						else if (zeroes == 1) {
							immediateInt += "0" + immediateInt;
						}
					}
					machineCode += immediateInt;
				}
				/*
				if (machineCode.length() < 6) {
					int zeroes = 6 - machineCode.length();
					if (zeroes == 5) {
						machineCode = "00000" + machineCode;
					}
					else if (zeroes == 4) {
						machineCode = "0000" + machineCode;
					}
					else if (zeroes == 3) {
						machineCode = "000" + machineCode;
					}
					else if (zeroes == 2) {
						machineCode = "00" + machineCode;
					}
					else if (zeroes == 1) {
						machineCode = "0" + machineCode;
					}
				}
				*/

			}
			//if (!machineCode.isEmpty()){
				//Long m = Long.parseLong(machineCode,2);
				//machineCode = Long.toHexString(m);
			//}
			
			machineCodes.add(machineCode);
			machineCodes.add("\n");
			machineCode = "";
		}

		return machineCodes;
	}

	public static boolean isNumeric(final char[] cs) {
		if (cs == null) {
			return false;
		}
		final int sz = cs.length;
		for (int i = 0; i < sz; i++) {
			if (!Character.isDigit(cs[i])){
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args){
		File asm = new File("data/assemblerTest.s");
		ArrayList<String> lines = AssemblyReader.AssemblyLines(asm);
		lines = AssembleInstruction(lines);

		PrintWriter writer;
		try {
			writer = new PrintWriter("data/Assembled.txt", "UTF-8");
			AssemblerWrite.AssemblerWriter(lines, writer);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/*
		 * need to export each ArrayList item to a file
		 * with newline character per instruction
		 * Look in Melse if example file for output format 
		 */
	}

}
