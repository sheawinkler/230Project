import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Scanner;

public class AssemblerWrite {
	public static void AssemblerWriter(ArrayList<String> al, Writer write){
		
		BufferedWriter bw;
		
		try {
			bw = new BufferedWriter(write);
			//write String of binary numbers to MIF file
			bw.write("-- Copyright (C) 1991-2011 Altera Corporation \n" +
"-- Your use of Altera Corporation\'s design tools, logic functions \n" +
"-- and other software and tools, and its AMPP partner logic \n" +
"-- functions, and any output files from any of the foregoing \n" +
"-- (including device programming or simulation files), and any \n" + 
"-- associated documentation or information are expressly subject \n" + 
"-- to the terms and conditions of the Altera Program License \n" + 
"-- Subscription Agreement, Altera MegaCore Function License \n" +
"-- Agreement, or other applicable license agreement, including, \n" +
"-- without limitation, that your use is for the sole purpose of \n" +
"-- programming logic devices manufactured by Altera and sold by \n" +
"-- Altera or its authorized distributors.  Please refer to the \n" +
"-- applicable agreement for further details. \n" +
"\n"+
"-- Quartus II generated Memory Initialization File (.mif) \n" +
"\n"+
"WIDTH=24;\n" +
"DEPTH=1024\n" +
"\n"+
"ADDRESS_RADIX=UNS;\n" +
"DATA_RADIX=HEX;\n" +
"\n" +
"CONTENT BEGIN" +
"\n");
			for (int i = 0; i < al.size(); i++){
				
				bw.write(al.get(i));
			}
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
